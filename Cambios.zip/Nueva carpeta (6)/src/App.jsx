import ReactDOM from 'react-dom/client'; // Importar createRoot desde react-dom/client
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Nav from './components/Nav';
import Inicio from './pages/Inicio';
import Institucion from './pages/Institucion';
import Contacto from './pages/Contacto';
import Footer from './components/Footer';
import Cursos from './pages/Cursos';
import '/public/styles/app.css'

function InicioPage() {
  return <Inicio />;
}

function CursosPage() {
  return <Cursos />;
}

function InstitucionPage() {
  return <Institucion />;
}

function ContactoPage() {
  return <Contacto />;
}

function App() {
  return (
    <Router>
      <Nav />
      <Routes>
        <Route path="/" element={<InicioPage />} />
        <Route path="/cursos/" element={<CursosPage />} />
        <Route path="/institucion/" element={<InstitucionPage />} />
        <Route path="/contacto/" element={<ContactoPage />} />
      </Routes>
      <Footer />
    </Router>
  );
}

// Cambiar a createRoot
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);

export default App
