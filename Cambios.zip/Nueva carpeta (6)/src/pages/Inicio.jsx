import '/public/styles/index.css'

function Inicio(){
    return(
        <>
            <div className="content">
                <div className="hero-image">
                    <div className="imagen-fondo"></div>
                    <div className="texto">
                    <h1>Accede a formacion practica y gratuita para desarrollar tu futuro profesional.</h1>
                    <h3>Ofrecemos cursos prácticos en diversas areas, diseñados para brindarte las habilidades necesarias para ingresar al mundo laboral. Accede a una formación de calidad, gratis, y potencia tu futuro</h3>
                    <a href="/cursos"><button>Ver Cursos Disponibles</button></a>
                    </div>
                </div>
                <div className="info-section">
                    <div className="quienes-somos">
                    <img src="/public/assets/inicio/frente.png" alt="" />
                    <div className="texto">
                        <h3>¿Quiénes somos?</h3>
                        <p>Somos una institución pública comprometida con brindar educación práctica y gratuita en una amplia variedad de oficios. Nuestra misión es ayudar a las personas a desarrollar habilidades que les permitan mejorar sus oportunidades laborales y construir un futuro mejor para ellas y sus comunidades.</p>
                    </div>
                    </div>
                    <div className="nuestra-mision">
                    <div className="texto">
                        <h3>Nuestra misión</h3>
                        <p>Empoderamos a nuestra comunidad mediante la educación y el aprendizaje práctico. Nuestra misión es ser un puente hacia nuevas oportunidades, brindando herramientas que fomenten el crecimiento personal y profesional, siempre enfocados en valores como la inclusión, la equidad y la excelencia. <a href="/institucion">Ver más..</a></p>
                    </div>
                    <img src="/public/assets/inicio/docentes.jpg" alt="" />
                    </div>
                </div>

                <div className="cursos-section">
                    <div className="title">
                    <h1>Cursos destacados</h1>
                    </div>
                    <div className="cards">
                        <div className="card-curso" onClick="location.href='/curso-detalle'">
                            <img src="/public/assets/inicio/carpinteria.jpg" alt="Imagen del curso" />
                            <div className="contenido">
                                <div className="nombre">Introducción a la Carpintería</div>
                                <div className="fecha">Inicio: 15 de febrero, 2025</div>
                            </div>
                        </div>
                        <div className="card-curso" onClick="location.href='/curso-detalle'">
                            <img src="/public/assets/inicio/carpinteria.jpg" alt="Imagen del curso" />
                            <div className="contenido">
                                <div className="nombre">Introducción a la Carpintería</div>
                                <div className="fecha">Inicio: 15 de febrero, 2025</div>
                            </div>
                        </div>
                        <div className="card-curso" onClick="location.href='/curso-detalle'">
                            <img src="/public/assets/inicio/carpinteria.jpg" alt="Imagen del curso" />
                            <div className="contenido">
                                <div className="nombre">Introducción a la Carpintería</div>
                                <div className="fecha">Inicio: 15 de febrero, 2025</div>
                            </div>
                        </div>
                        <div className="card-curso" onClick="location.href='/curso-detalle'">
                            <img src="/public/assets/inicio/carpinteria.jpg" alt="Imagen del curso" />
                            <div className="contenido">
                                <div className="nombre">Introducción a la Carpintería</div>
                                <div className="fecha">Inicio: 15 de febrero, 2025</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
export default Inicio