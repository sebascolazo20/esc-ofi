import { useState } from 'react';
import '/public/styles/cursos.css';
import categoriasData from '/src/categorias.json';
import cursosData from '/src/cursos.json';

function Cursos() {
    const [categorias] = useState(categoriasData.Categorias);
    const [categoriaSeleccionada, setCategoriaSeleccionada] = useState(null);
    const [cursos, setCursos] = useState([]);
    const [cursoSeleccionado, setCursoSeleccionado] = useState(null);

    const handleClickCategoria = (categoriaId) => {
        const categoria = categorias.find((cat) => cat.id === categoriaId);
        if (categoria) {
            setCategoriaSeleccionada(categoria);
            const cursosFiltrados = cursosData.Cursos.filter((curso) =>
                Array.isArray(curso.categoriaIds) && curso.categoriaIds.includes(categoriaId)
            );
            setCursos(cursosFiltrados);
        }
    };

    const handleClickCurso = (cursoId) => {
        const curso = cursos.find((curso) => curso.id === cursoId);
        if (curso) {
            setCursoSeleccionado(curso);
        } else {
            console.error('Curso no encontrado');
        }
    };

    const handleVolverCategorias = () => {
        setCategoriaSeleccionada(null);
        setCursos([]);
        setCursoSeleccionado(null);
    };

    const handleVolverCursos = () => {
        if (categoriaSeleccionada) {
            const categoriaId = categoriaSeleccionada.id;
            const cursosFiltrados = cursosData.Cursos.filter((curso) =>
                Array.isArray(curso.categoriaIds) && curso.categoriaIds.includes(categoriaId)
            );
            setCursos(cursosFiltrados);
            setCursoSeleccionado(null);
        }
    };

    return (
        <div id="root">
            <div className="categorias-container">
                {cursoSeleccionado ? (
                    <>
                        <h1 className="categorias-title">{cursoSeleccionado.nombre}</h1>
                        <div className="curso-detalle">
                            <div className="curso-info-left">
                                <img
                                    src={`/public/assets/cursos/categorias/${cursoSeleccionado.imagen}`}
                                    alt={cursoSeleccionado.nombre}
                                    className="curso-imagen"
                                />
                                <div className="sobre-curso">
                                    <h3>Sobre el curso:</h3>
                                    <p>{cursoSeleccionado.descripcion}</p>
                                </div>
                            </div>
                            <div className="curso-info-right">
                                <h2>Detalles del curso</h2>
                                <p><strong>Duración:</strong> {cursoSeleccionado.duracion}</p>
                                <p><strong>Carga horaria total:</strong> {cursoSeleccionado.cargaHoraria}</p>
                                <p><strong>Días y horarios:</strong> {cursoSeleccionado.diasHorarios}</p>
                                <p><strong>Inicio:</strong> {cursoSeleccionado.inicio}</p>
                                <p><strong>Lugar:</strong> {cursoSeleccionado.lugar}</p>

                                <h3>Al finalizar:</h3>
                                <ul>
                                    {cursoSeleccionado.logros.map((logro, index) => (
                                        <li key={index}>{logro}</li>
                                    ))}
                                </ul>

                                <h3>Requisitos:</h3>
                                <ul>
                                    {cursoSeleccionado.requisitos.map((requisito, index) => (
                                        <li key={index}>{requisito}</li>
                                    ))}
                                </ul>

                                <button className="inscribirse-btn">Inscribirse</button>
                                <button className="volver-btn" onClick={handleVolverCursos}>Volver a los cursos</button>
                            </div>
                        </div>
                    </>
                ) : categoriaSeleccionada ? (
                    <>
                        <h1 className="categorias-title">{categoriaSeleccionada.nombre}</h1>
                        <div className="cursos-container">
                            {cursos.map((curso) => (
                                <div className="card-curso" key={curso.id} onClick={() => handleClickCurso(curso.id)}>
                                    <img
                                        src={`/public/assets/cursos/categorias/${curso.imagen}`}
                                        alt={curso.nombre}
                                    />
                                    <div className="contenido">
                                        <div className="nombre">{curso.nombre}</div>
                                        <div className="fecha">
                                            <span>{curso.duracion}</span> - <span>{curso.inicio}</span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <button className="volver-btn" onClick={handleVolverCategorias}>Volver a las categorías</button>
                    </>
                ) : (
                    <>
                        <h1 className="categorias-title">Oficios</h1>
                        <div className="categorias-gallery">
                            {categorias.map((categoria) => (
                                <div
                                    className="categoria-card"
                                    key={categoria.id}
                                    onClick={() => handleClickCategoria(categoria.id)}
                                >
                                    <img
                                        src={`/public/assets/cursos/categorias/${categoria.imagen}`}
                                        alt={categoria.nombre}
                                        className="categoria-image"
                                    />
                                    <div className="categoria-overlay">{categoria.nombre}</div>
                                </div>
                            ))}
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}

export default Cursos;
